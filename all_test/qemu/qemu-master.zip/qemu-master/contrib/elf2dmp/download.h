/*
 * Copyright (c) 2018 Virtuozzo International GmbH
 *
 * This work is licensed under the terms of the GNU GPL, version 2 or later.
 *
 */

#ifndef DOWNLOAD_H
#define DOWNLOAD_H

int download_url(const char *name, const char *url);

#endif /* DOWNLOAD_H */
