.. QEMU documentation master file, created by
   sphinx-quickstart on Thu Jan 31 16:40:14 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to QEMU's documentation!
================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   interop/index
   devel/index

